# Sinclair Design Atelier CRM

A branded CRM starter built for Sinclair Design Atelier using Next.js App Router.

## Included
- Dashboard / studio overview
- Lead pipeline
- Clients
- Projects
- Invoices
- Tasks
- Responsive dark + champagne visual system matching the Sinclair brand direction

## Run locally
```bash
npm install
npm run dev
```
Then open http://localhost:3000.

## Production roadmap
This first version uses sample data in `lib/data.js`. For production, connect it to a hosted Postgres database (Supabase or Neon), add authentication, role-based access, file uploads, email integration, Stripe invoices/payments, automated follow-ups, and wire the website inquiry form into the Leads table.

## Suggested entity model
- leads: company, contact, email, phone, source, stage, estimated_value, notes, next_action, next_action_date
- clients: company, primary_contact, email, phone, billing_address, status
- projects: client_id, name, scope, phase, contract_value, start_date, due_date, progress
- invoices: client_id, project_id, invoice_number, amount, status, due_date, paid_at
- tasks: client_id, project_id, title, priority, due_date, completed
- activities: lead/client/project references, activity_type, note, created_at

import { leads, projects, invoices, tasks } from '../lib/data';
const money = n => '$'+n.toLocaleString();
export default function Dashboard(){
 const pipeline=leads.reduce((a,l)=>a+l.value,0), revenue=invoices.filter(i=>i.status==='Paid').reduce((a,i)=>a+i.amount,0);
 return <>
  <div className="page-head"><div><p className="eyebrow">STUDIO OVERVIEW</p><h1>Good evening, Sinclair.</h1><p>Here’s what’s moving across the atelier.</p></div><button className="primary">+ New lead</button></div>
  <section className="metrics">
   <Metric label="Pipeline value" value={money(pipeline)} note="4 active opportunities"/>
   <Metric label="Active projects" value={projects.length} note="1 nearing launch"/>
   <Metric label="Collected revenue" value={money(revenue)} note="Current invoice set"/>
   <Metric label="Open tasks" value={tasks.length} note="2 high priority"/>
  </section>
  <div className="grid-two">
   <section className="panel"><div className="panel-head"><div><p className="eyebrow">SALES PIPELINE</p><h2>Opportunities</h2></div><a href="/leads">View all</a></div><div className="pipeline">{['New Inquiry','Qualified','Discovery','Proposal'].map(stage=><div className="stage" key={stage}><div className="stage-title"><span>{stage}</span><small>{leads.filter(l=>l.stage===stage).length}</small></div>{leads.filter(l=>l.stage===stage).map(l=><div className="lead-card" key={l.name}><strong>{l.name}</strong><span>{l.contact}</span><b>{money(l.value)}</b><small>{l.next} · {l.date}</small></div>)}</div>)}</div></section>
   <section className="panel"><div className="panel-head"><div><p className="eyebrow">DELIVERY</p><h2>Projects</h2></div><a href="/projects">View all</a></div>{projects.map(p=><div className="project-row" key={p.name}><div><strong>{p.name}</strong><span>{p.client}</span></div><div className="progress-wrap"><div className="progress"><i style={{width:p.progress+'%'}}/></div><small>{p.progress}%</small></div></div>)}</section>
  </div>
  <section className="panel"><div className="panel-head"><div><p className="eyebrow">NEXT UP</p><h2>Priority tasks</h2></div><a href="/tasks">View all</a></div>{tasks.slice(0,3).map(t=><div className="task-row" key={t.task}><span className="check"></span><div><strong>{t.task}</strong><small>{t.project}</small></div><span className={`pill ${t.priority.toLowerCase()}`}>{t.priority}</span><b>{t.due}</b></div>)}</section>
 </>
}
function Metric({label,value,note}){return <div className="metric"><span>{label}</span><strong>{value}</strong><small>{note}</small></div>}

'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Users, BriefcaseBusiness, ReceiptText, CheckSquare, Contact, Search, Bell } from 'lucide-react';

const nav = [
  ['/', 'Dashboard', LayoutDashboard],
  ['/leads', 'Leads', Contact],
  ['/clients', 'Clients', Users],
  ['/projects', 'Projects', BriefcaseBusiness],
  ['/invoices', 'Invoices', ReceiptText],
  ['/tasks', 'Tasks', CheckSquare]
];

export default function Shell({ children }) {
  const path = usePathname();
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">S</div><div><strong>Sinclair</strong><span>Design Atelier</span></div></div>
      <nav>{nav.map(([href,label,Icon]) => <Link key={href} href={href} className={path===href?'active':''}><Icon size={18}/><span>{label}</span></Link>)}</nav>
      <div className="sidebar-foot"><div className="avatar">SD</div><div><strong>Studio Admin</strong><span>Owner</span></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="search"><Search size={17}/><input placeholder="Search clients, projects, invoices..."/></div><button className="icon-btn"><Bell size={18}/></button></header>
      <div className="content">{children}</div>
    </main>
  </div>
}

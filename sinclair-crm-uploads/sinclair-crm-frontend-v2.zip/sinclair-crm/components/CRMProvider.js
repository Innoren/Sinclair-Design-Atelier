'use client';
import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { seedData } from '../lib/data';

const CRMContext = createContext(null);
const STORAGE_KEY = 'sinclair-crm-demo-v2';

export function CRMProvider({ children }) {
  const [data, setData] = useState(seedData);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) setData(JSON.parse(saved));
    } catch (e) {
      console.warn('Could not load saved CRM demo data', e);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data, hydrated]);

  const addItem = (type, item) => {
    setData(current => ({
      ...current,
      [type]: [{ ...item, id: crypto.randomUUID() }, ...current[type]],
    }));
  };

  const toggleTask = id => {
    setData(current => ({
      ...current,
      tasks: current.tasks.map(task => task.id === id ? { ...task, completed: !task.completed } : task),
    }));
  };

  const resetDemo = () => {
    setData(seedData);
    localStorage.removeItem(STORAGE_KEY);
  };

  const value = useMemo(() => ({ data, addItem, toggleTask, resetDemo, hydrated }), [data, hydrated]);
  return <CRMContext.Provider value={value}>{children}</CRMContext.Provider>;
}

export function useCRM() {
  const context = useContext(CRMContext);
  if (!context) throw new Error('useCRM must be used inside CRMProvider');
  return context;
}

'use client';
import Link from 'next/link';
import { useState } from 'react';
import { useCRM } from '../components/CRMProvider';
import Modal from '../components/Modal';

const money = n => '$'+Number(n||0).toLocaleString();
export default function Dashboard(){
 const { data, addItem }=useCRM(); const {leads,projects,invoices,tasks}=data; const [open,setOpen]=useState(false);
 const pipeline=leads.reduce((a,l)=>a+Number(l.value||0),0), revenue=invoices.filter(i=>i.status==='Paid').reduce((a,i)=>a+Number(i.amount||0),0);
 function submit(e){e.preventDefault();const f=new FormData(e.currentTarget);addItem('leads',{name:f.get('name'),contact:f.get('contact'),email:f.get('email'),value:Number(f.get('value')),stage:'New Inquiry',source:'Manual',next:'Initial response',date:'Today'});setOpen(false);}
 return <>
  <div className="page-head"><div><p className="eyebrow">STUDIO OVERVIEW</p><h1>Good evening, Sinclair.</h1><p>Here’s what’s moving across the atelier.</p></div><button className="primary" onClick={()=>setOpen(true)}>+ New lead</button></div>
  <section className="metrics"><Metric label="Pipeline value" value={money(pipeline)} note={`${leads.length} active opportunities`}/><Metric label="Active projects" value={projects.length} note={`${projects.filter(p=>p.progress>=75).length} nearing launch`}/><Metric label="Collected revenue" value={money(revenue)} note="From recorded paid invoices"/><Metric label="Open tasks" value={tasks.filter(t=>!t.completed).length} note={`${tasks.filter(t=>t.priority==='High'&&!t.completed).length} high priority`}/></section>
  <div className="grid-two">
   <section className="panel"><div className="panel-head"><div><p className="eyebrow">SALES PIPELINE</p><h2>Opportunities</h2></div><Link href="/leads">View all</Link></div><div className="pipeline">{['New Inquiry','Qualified','Discovery','Proposal'].map(stage=><div className="stage" key={stage}><div className="stage-title"><span>{stage}</span><small>{leads.filter(l=>l.stage===stage).length}</small></div>{leads.filter(l=>l.stage===stage).map(l=><div className="lead-card" key={l.id}><strong>{l.name}</strong><span>{l.contact}</span><b>{money(l.value)}</b><small>{l.next} · {l.date}</small></div>)}</div>)}</div></section>
   <section className="panel"><div className="panel-head"><div><p className="eyebrow">DELIVERY</p><h2>Projects</h2></div><Link href="/projects">View all</Link></div>{projects.map(p=><div className="project-row" key={p.id}><div><strong>{p.name}</strong><span>{p.client}</span></div><div className="progress-wrap"><div className="progress"><i style={{width:p.progress+'%'}}/></div><small>{p.progress}%</small></div></div>)}</section>
  </div>
  <section className="panel"><div className="panel-head"><div><p className="eyebrow">NEXT UP</p><h2>Priority tasks</h2></div><Link href="/tasks">View all</Link></div>{tasks.filter(t=>!t.completed).slice(0,3).map(t=><div className="task-row" key={t.id}><span className="check"></span><div><strong>{t.task}</strong><small>{t.project}</small></div><span className={`pill ${t.priority.toLowerCase()}`}>{t.priority}</span><b>{t.due}</b></div>)}</section>
  <Modal open={open} onClose={()=>setOpen(false)} title="Add a new lead"><form className="form-grid" onSubmit={submit}><Field label="Company / brand" name="name" required/><Field label="Contact name" name="contact" required/><Field label="Email" name="email" type="email"/><Field label="Estimated value" name="value" type="number" required/><div className="form-actions"><button type="button" className="secondary" onClick={()=>setOpen(false)}>Cancel</button><button className="primary">Create lead</button></div></form></Modal>
 </>;
}
function Metric({label,value,note}){return <div className="metric"><span>{label}</span><strong>{value}</strong><small>{note}</small></div>}
function Field({label,...props}){return <label className="field"><span>{label}</span><input {...props}/></label>}

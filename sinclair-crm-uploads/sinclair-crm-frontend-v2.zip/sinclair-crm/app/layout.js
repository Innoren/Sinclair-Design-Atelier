import './globals.css';
import { Outfit, Source_Sans_3 } from 'next/font/google';
import Shell from '../components/Shell';
import { CRMProvider } from '../components/CRMProvider';

const outfit = Outfit({ subsets: ['latin'], variable: '--font-outfit' });
const source = Source_Sans_3({ subsets: ['latin'], variable: '--font-source' });

export const metadata = { title: 'Sinclair CRM', description: 'Studio CRM for Sinclair Design Atelier' };

export default function RootLayout({ children }) {
  return <html lang="en"><body className={`${outfit.variable} ${source.variable}`}><CRMProvider><Shell>{children}</Shell></CRMProvider></body></html>;
}
